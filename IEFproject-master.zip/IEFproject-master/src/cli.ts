import readlineSync from 'readline-sync'

const Cfont = 